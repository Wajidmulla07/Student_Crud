package com.student.api.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.student.api.repository.StudentRepo;

@ExtendWith(MockitoExtension.class)
public class StudentServiceTest {

	@Mock
	private StudentRepo studRepo;

	private StudentService studServ;
	
	@BeforeEach
	void setUp() {
		
		this.studServ=new StudentService(studRepo);
	}
	
//	@Test
//	void testGetStudents() {
//
//		studServ.getStudents();
//
//		verify(studRepo).findAll();
//
//	}

	
	  @Test 
	  void testGetStudent() {
		  int studId = 16;
		 studServ.getStudent(studId); 
		 
		 verify(studRepo).findById(studId);

	  }
	  
	  @Test void testAddStudent() {
		  
		 
		  
	  }
	  
	 /* @Test void testUpdateStudent() { fail("Not yet implemented"); }
	 * 
	 * @Test void testDeleteStudent() { fail("Not yet implemented"); }
	 */
}
