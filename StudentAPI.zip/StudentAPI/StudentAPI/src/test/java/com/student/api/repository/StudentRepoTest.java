package com.student.api.repository;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.student.api.entity.Student;

@SpringBootTest
class StudentRepoTest {

	@Autowired
	private StudentRepo studRepo;
	
	@Test
	void testIsStudentExistsById() {
	
		Student stud = new Student(100,"Amit","amit@gmail.com","Bhopal");
		studRepo.save(stud);
		
		boolean actualResult = studRepo.isStudentExistsById(100);
		
		assertThat(actualResult).isTrue();
		
	}

}
