package com.student.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.student.api.entity.Student;

public interface StudentRepo extends CrudRepository<Student, Integer> {

	
	@Query("Select CASE WHEN COUNT(s)>0 THEN TRUE ELSE FALSE END FROM Student s WHERE s.id =:id")
	Boolean isStudentExistsById(@Param("id") Integer id);
	
}
