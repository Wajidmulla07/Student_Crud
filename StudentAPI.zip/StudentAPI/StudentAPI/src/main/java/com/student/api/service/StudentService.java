package com.student.api.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.api.entity.Student;
import com.student.api.repository.StudentRepo;

@Service
public class StudentService {

	@Autowired
	StudentRepo studRepo;
	
	public StudentService(StudentRepo studRepo2) {
		this.studRepo = studRepo2;
	}

	public List<Student> getStudents(){
		List<Student> students=(List<Student>)studRepo.findAll();
		return students;
	}

	public Optional<Student> getStudent(int studId) {
		Optional<Student> student=null;
		student = studRepo.findById(studId);
		return student;	
	}

	public Student addStudent(Student student) {
		Student stud=studRepo.save(student);
		return stud;
	}

	public void updateStudent(Student student, int studId) {
		student.setId(studId);
		studRepo.save(student);
		
	}

	public void deleteStudent(int studId) {
		studRepo.deleteById(studId);
	}
	
	
	
}
