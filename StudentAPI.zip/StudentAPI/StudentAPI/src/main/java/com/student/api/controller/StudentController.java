package com.student.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.api.entity.Student;
import com.student.api.service.StudentService;



@RestController
public class StudentController {
	
	@Autowired
	StudentService ss;

	@GetMapping("/students")
	public List<Student> getStudents(){
		return ss.getStudents();
	}
	
	@GetMapping("/students/{studId}")
	public Optional<Student> getStudent(@PathVariable int studId) {
		return ss.getStudent(studId);
	}
	
	@PostMapping("/students")
	public Student addStudent(@RequestBody Student student) {
		return ss.addStudent(student);
	}
	
	@PutMapping("/students/{studId}")
	public void updateStudent(@RequestBody Student student,@PathVariable int studId) {
		ss.updateStudent(student, studId);
	}
	
	@DeleteMapping("/students/{studId}")
	public void deleteStudent(@PathVariable int studId) {
		ss.deleteStudent(studId);
	}

}
